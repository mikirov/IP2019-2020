package com.example.fileshare.exception;

public class StorageFileNotFoundException extends Throwable {
}
