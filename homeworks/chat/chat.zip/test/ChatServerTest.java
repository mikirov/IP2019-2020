public class ChatServerTest {
}
